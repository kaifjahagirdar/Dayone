# Day1
## github study
### lets learn something
welcome to EC
License


1) MIT License
The MIT License is a permissive free software license originating at the Massachusetts Institute of Technology (MIT)[6] in the late 1980s.[7] As a permissive license, it puts only very limited restriction on reuse and has, therefore, high license compatibility.[8][9]

The MIT License is compatible with many copyleft licenses, such as the GNU General Public License (GNU GPL). Any software licensed under the terms of the MIT License can be integrated with software licensed under the terms of the GNU GPL.[10] Unlike copyleft software licenses, the MIT License also permits reuse within proprietary software, provided that all copies of the software or its substantial portions include a copy of the terms of the MIT License and also a copyright notice.[9][11] As of 2020, the MIT License was the most popular software license found in one analysis,[12] continuing from reports in 2015 that the MIT License was the most popular software license on GitHub.[13]

Notable projects that use the MIT License include the X Window System, Ruby on Rails, Nim, Node.js, Lua, and jQuery. Notable companies using the MIT License include Microsoft (.NET Core), Google (Angular), and Meta (React).


2)Apache License
The Apache License is a permissive free software license written by the Apache Software Foundation (ASF).[4] It allows users to use the software for any purpose, to distribute it, to modify it, and to distribute modified versions of the software under the terms of the license, without concern for royalties. The ASF and its projects release their software products under the Apache License. The license is also used by many non-ASF projects.


3)GNU License
The GNU General Public License (GNU GPL or simply GPL) is a series of widely used free software licenses that guarantee end users the four freedoms to run, study, share, and modify the software.[7] The license was the first copyleft for general use and was originally written by the founder of the Free Software Foundation (FSF), Richard Stallman, for the GNU Project. The license grants the recipients of a computer program the rights of the Free Software Definition.[8] These GPL series are all copyleft licenses, which means that any derivative work must be distributed under the same or equivalent license terms. It is more restrictive than the Lesser General Public License and even further distinct from the more widely used permissive software licenses BSD, MIT, and Apache


4)BSD 2 Clouse License
Also known as the “simplified BSD license” and "freeBSD license," the 2-Clause BSD license omits the third clause of the BSD 3 (also known as the “non-endorsement clause”). This is the clause that prohibits users from using the name of the project to promote their derivative work (s).
